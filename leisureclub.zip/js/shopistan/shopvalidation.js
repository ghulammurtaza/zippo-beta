    if(Validation) {  
Validation.addAllThese([
[
'paki-mobile',
'Please enter a valid mobile number :03XXXXXXXXX (example 0312 1231231)',
function(v)
{
return Validation.get('IsEmpty').test(v) || /^([0][3]\d{2}\d{7})$/.test(v);
            }],

    ['validate-cphone', 'Please make sure your mobile numbers match.', function(v) {  
                var conf = $('confirmation') ? $('confirmation') : $$('.validate-cphone')[0];  
                var pass = false;  
  var confirm;

         //   alert($('billing:telephone').value + "===="+$('tel2').value);  
                if ($('billing:telephone')) {  
                    pass = $('billing:telephone');  
                }  
  confirm =conf.value;  
  if(!confirm && $('tel2'))  
  {  
  confirm = $('tel2').value;  
  }  
                return (pass.value == confirm);  
            }],



            ['validate-scphone', 'Please make sure your mobile numbers match.', function(v) {  
                var conf = $('confirmation') ? $('confirmation') : $$('.validate-scphone')[0];  
                var pass = false;  
  var confirm;

          // alert($('shipping:telephone').value + "===="+$('tel3').value);  
                if ($('shipping:telephone')) {  
                    pass = $('shipping:telephone');  
                }  
  confirm =conf.value;  
  if(!confirm && $('tel3'))  
  {  
  confirm = $('tel3').value;  
  }  
                return (pass.value == confirm);  
            }],  


])
}
